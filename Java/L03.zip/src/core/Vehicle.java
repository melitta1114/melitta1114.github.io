package core;

public interface Vehicle {
    public String toString();
    public void numberOfWheels();
}
