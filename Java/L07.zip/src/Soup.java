public interface Soup {
    public void associateMainDish(MainDish mainDish);
    public String toString();
}
