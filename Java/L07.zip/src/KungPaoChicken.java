public class KungPaoChicken implements MainDish{
    public String toString(){
        return getClass().getSimpleName();
    }
}
