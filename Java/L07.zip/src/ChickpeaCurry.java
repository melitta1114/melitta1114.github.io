public class ChickpeaCurry implements MainDish{
    public String toString(){

        return getClass().getSimpleName() ;
    }
}
