public interface Chef {
    public Soup prepareSoup();
    public MainDish prepareMainDish();
}
